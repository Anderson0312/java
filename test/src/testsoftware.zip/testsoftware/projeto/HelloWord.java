package testsoftware.projeto;


public class HelloWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("hellw world");
	}

}
